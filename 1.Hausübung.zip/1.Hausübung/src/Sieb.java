
import java.util.ArrayList;


class EratosthenesPrimeSieve {

    static int og = 100;
    static boolean[] prime = new boolean[og+1];



    public static void main(String[] args) {
        aufgabe1();
        aufgabe2();

    }

    public static void aufgabe1() {
        sieb(og);


        printPrimes();
    }
    public static void aufgabe2(){
        ArrayList<Integer> primenumbers = new ArrayList<>();
        for (int i = 2; i < prime.length; i++) {
            if ((prime[i]==false)){
                primenumbers.add(i);
            }
        }

        System.out.println(primenumbers);
        for (int i = 4; i < og; i+=2) {// Wird berechnet

            for (int j = 2; j < og; j++) {// 1. Primzahl
                for (int k = 0; k < og; k++) {// 2. Primzahl

                    if(primenumbers.contains(j)&&primenumbers.contains(k)) {


                        if ((j + k) == i) {
                            System.out.println(i + " = " + j + " + " + k);
                            k= og;
                            j = og;
                        }
                    }
                }
                }

            }


    }

    public static void sieb(int pObergraenze) {
        for (int i = 2; i < og; i++) {

            for (int j = 2; j < og;j++) {
                if (i*j<=og)
                    prime[i*j] = true;


            }


        }
    }





    //    @Override
    public static void printPrimes() {
        for (int i = 0; i < prime.length; i++) {
            if (!prime[i])
            {
                System.out.println(i);

            }
        }

    }
}
